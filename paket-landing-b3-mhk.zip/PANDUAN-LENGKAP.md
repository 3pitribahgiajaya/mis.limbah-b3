# Panduan Lengkap: Landing Page Limbah B3 — PT Multi Hanna Kreasindo

Paket ini berisi semua yang dibutuhkan untuk menaikkan landing page online dan mulai muncul di pencarian Google. Ikuti urutan di bawah — jangan lompat langkah.

**Isi paket:**
- `index.html` — landing page (redirect otomatis ke WhatsApp)
- `robots.txt` — izin untuk Google merayapi situs
- `sitemap.xml` — peta situs untuk didaftarkan ke Google
- `PANDUAN-LENGKAP.md` — file ini

---

## LANGKAH 1 — Upload ke GitHub Pages (gratis, 15 menit)

1. Buka **github.com**, daftar/login (pakai email kantor).
2. Klik **+** (kanan atas) → **New repository**.
   - Nama: `limbah-b3`
   - Visibility: **Public**
   - Klik **Create repository**
3. Di halaman repo, klik **Add file → Upload files**.
4. Upload ketiga file: `index.html`, `robots.txt`, `sitemap.xml`.
5. Klik **Commit changes**.
6. Masuk **Settings → Pages** (menu kiri).
7. Bagian **Branch**: pilih `main`, folder `/root` → **Save**.
8. Tunggu 1–2 menit. URL publik akan muncul, formatnya:
   `https://namaakun.github.io/limbah-b3/`
9. Buka URL itu di HP — pastikan redirect WhatsApp jalan otomatis (sebelumnya diblokir hanya karena masih di dalam preview Claude, di luar itu akan normal).

> **Jika PT MHK sudah punya domain sendiri** (mis. `multihanna.co.id`), lebih baik pakai domain itu daripada `github.io` — lanjut ke Langkah 2. Kalau belum punya domain, lewati ke Langkah 3 dan pakai URL `github.io` dulu.

---

## LANGKAH 2 — (Opsional) Pasang Domain Sendiri

1. Beli domain jika belum ada (Niagahoster/Namecheap/Domainesia, ~Rp150–200rb/tahun).
2. Di pengaturan DNS domain, tambahkan:
   - Tipe `A` mengarah ke IP GitHub Pages: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - Atau `CNAME` mengarah ke `namaakun.github.io`
3. Di repo GitHub → **Settings → Pages → Custom domain**, masukkan domain anda, lalu **Save**.
4. Tunggu propagasi DNS (bisa sampai 24 jam).
5. **Update file `robots.txt` dan `sitemap.xml`**: ganti `GANTI-DENGAN-DOMAIN-ANDA` dengan domain asli anda, lalu upload ulang ke GitHub.

---

## LANGKAH 3 — Daftarkan ke Google Search Console (wajib untuk muncul di pencarian)

1. Buka **search.google.com/search-console**.
2. Tambah properti → masukkan URL situs anda (domain atau `github.io` anda).
3. Verifikasi kepemilikan (Google kasih beberapa opsi — untuk GitHub Pages, cara termudah pakai metode **HTML tag**: Google kasih 1 baris kode `<meta>`, tempel ke bagian `<head>` file `index.html`, lalu upload ulang).
4. Setelah terverifikasi, masuk ke menu **Sitemaps** → masukkan `sitemap.xml` → **Submit**.
5. Masuk ke **URL Inspection**, masukkan URL halaman anda → klik **Request Indexing**.
6. Google biasanya butuh **beberapa hari–2 minggu** untuk mulai menampilkan halaman di hasil pencarian.

---

## LANGKAH 4 — Google Business Profile (PALING PENTING untuk pencarian lokal)

Untuk pencarian seperti *"jasa limbah B3 Jawa Barat"*, orang lebih sering klik hasil **Google Maps/Bisnis**, bukan website biasa. Ini yang paling cepat memberi hasil nyata.

1. Buka **business.google.com**.
2. Klik **Kelola sekarang** → masukkan nama: **PT Multi Hanna Kreasindo**.
3. Kategori bisnis: pilih **"Waste management service"** (atau kategori terdekat dalam bahasa Indonesia: "Layanan pengelolaan limbah").
4. Isi alamat kantor, area layanan (JABAR, JATENG, JATIM — sesuai wilayah operasional), nomor telepon (0899-9324-847), dan **link website** (URL landing page dari Langkah 1/2).
5. Verifikasi bisnis — biasanya via kartu pos fisik ke alamat kantor, atau video call/telepon (Google akan memandu opsi yang tersedia).
6. Setelah terverifikasi, lengkapi profil: foto kantor/armada, jam operasional, deskripsi layanan (masukkan kata kunci: "pengelolaan limbah B3", "pengangkutan limbah B3", "manifest elektronik").

---

## LANGKAH 5 — Perkuat Kata Kunci (SEO on-page)

Landing page sudah punya meta description dan schema.org dasar. Untuk hasil lebih baik, tambahkan variasi kata kunci lokasi ke dalam teks halaman, misalnya:
- "Jasa pengelolaan limbah B3 Jawa Barat"
- "Pengangkutan limbah B3 Bandung / Jakarta / Surabaya"
- "Limbah medis fasyankes B3"

Semakin spesifik kata kunci sesuai wilayah target, semakin mudah muncul untuk pencarian lokal.

---

## LANGKAH 6 — (Opsional, untuk hasil instan) Google Ads

SEO organik butuh waktu minggu–bulan. Kalau butuh muncul di hasil pencarian **segera**, jalankan **Google Search Ads** untuk kata kunci seperti "jasa limbah B3", "pengelolaan limbah B3 [kota]" sambil menunggu SEO organik naik. Budget bisa mulai kecil (Rp50–100rb/hari) untuk uji coba.

---

## Ringkasan Prioritas

| Prioritas | Langkah | Dampak |
|---|---|---|
| 1 | Upload ke GitHub Pages | Website online |
| 2 | Google Business Profile | Muncul di Maps/pencarian lokal — **paling cepat terasa** |
| 3 | Google Search Console | Muncul di hasil pencarian organik |
| 4 | Domain sendiri | Terlihat lebih profesional & kredibel |
| 5 | Google Ads | Hasil instan sambil menunggu SEO organik |
